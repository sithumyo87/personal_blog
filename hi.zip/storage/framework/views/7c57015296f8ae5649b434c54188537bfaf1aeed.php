<?php $__env->startSection('title','Coding Skill'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card mt-5 p-4">
        <div class="card-header bg-primary text-white"><h4>Certificate Create Form</h4></div>
        <div class="card-body">
            <form action="<?php echo e(route('certificate.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-dismissible fade show alert-danger" role="alert"  id="customxD">
                        <strong><?php echo e($error); ?></strong>
                        <button type="button" class="btn-close" data-mdb-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group ">
                    <label for="name">Certificate Name</label>
                    <input type="text" placeholder="Enter Certificate Name" name="name" class="form-control">
                </div>
                <div class="form-group ">
                    <label for="name">Image</label>
                    <input type="file"  name="image" class="form-control">
                </div>
                <button class="btn btn-primary mt-3"><i class="fas fa-paper-plane">Submit</i></button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PersonalBlog\resources\views/admin/Certificate/create.blade.php ENDPATH**/ ?>