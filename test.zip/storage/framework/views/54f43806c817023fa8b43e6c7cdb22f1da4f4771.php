<?php $__env->startSection('title','Coding Skill'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card mt-5 p-4">
        <div class="card-header bg-primary text-white">
            <h4>Knowledge Form List</h4>
        </div>
        <div class="card-body">
            <div class="d-flex justify-content-end mb-3">
                <a href="<?php echo e(route('knowledge.create')); ?>"><button class="btn btn-success float-right"><i class="fas fa-plus-circle"></i>Add Skill</button></a>
            </div>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-dismissible fade show alert-danger" role="alert"  id="customxD">
                    <strong><?php echo e($error); ?></strong>
                    <button type="button" class="btn-close" data-mdb-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(session('msg')): ?>
                <div class="alert alert-dismissible fade show alert-success" role="alert"  id="customxD">
                    <strong><?php echo e(session('msg')); ?></strong>
                    <button type="button" class="btn-close" data-mdb-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
                <?php if(session('delmsg')): ?>
                    <div class="alert alert-dismissible fade show alert-danger" role="alert"  id="customxD">
                        <strong><?php echo e(session('delmsg')); ?></strong>
                        <button type="button" class="btn-close" data-mdb-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>



           <table class="table table-striped">
               <thead>
               <tr>
                   <th>Id</th>
                   <th>Name</th>
                   <th>Action</th>
               </tr>
               </thead>
               <tbody>
               <?php $__currentLoopData = $knowledges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                   <td><?php echo e($k->id); ?></td>
                   <td><?php echo e($k->name); ?> </td>
                   <td>
                       <form action="<?php echo e(route('knowledge.destroy',$k->id)); ?>" method="post">
                           <?php echo csrf_field(); ?>
                           <?php echo method_field('DELETE'); ?>
                       <a href="<?php echo e(route('knowledge.edit',$k->id)); ?>" class="btn btn-sm btn-success"><i class="fas fa-edit"></i>Edit</a>
                           <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure to delete?')"><i class="fas fa-trash-alt"></i> Delete</button>
                       </form>
                   </td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
           </table>
            <div class="d-flex ">
                <?php echo $knowledges->links(); ?>

            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PersonalBlog\resources\views/admin/Knowledge/index.blade.php ENDPATH**/ ?>