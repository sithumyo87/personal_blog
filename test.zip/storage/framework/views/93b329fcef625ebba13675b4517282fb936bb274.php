<?php $__env->startSection('title','Coding Skill'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card mt-5 p-4">
        <div class="card-header bg-primary text-white"><h4>Edit Portfolio Form</h4></div>
        <div class="card-body">
            <form action="<?php echo e(route('portfolio.update',$portfolio->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-dismissible fade show alert-danger" role="alert"  id="customxD">
                        <strong><?php echo e($error); ?></strong>
                        <button type="button" class="btn-close" data-mdb-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(session('msg')): ?>
                    <div class="alert alert-dismissible fade show alert-success" role="alert"  id="customxD">
                        <strong><?php echo e(session('msg')); ?></strong>
                        <button type="button" class="btn-close" data-mdb-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <div class="form-group mt-3">
                    <label for="name">Other Knowledge</label>
                    <input type="text" placeholder="Enter your Other Knowledge" name="name" class="form-control" value="<?php echo e($portfolio->name); ?>">
                </div>
                <div class="form-group mt-3">
                    <label for="url">URL Name</label>
                    <input type="text" placeholder="Enter Url" name="url" class="form-control" value="<?php echo e($portfolio->url); ?>">
                </div>
                <div class="form-group mt-3">
                    <label for="name">Image</label>
                    <input type="file"  name="image" class="form-control" >
                </div>
                <div>
                    <img src="<?php echo e(Storage::url($portfolio->image)); ?>" width="140px" alt="" class="mt-3">
                </div>
                <button class="btn btn-primary mt-3"><i class="fas fa-paper-plane">Updated</i></button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PersonalBlog\resources\views/admin/Portfolio/edit.blade.php ENDPATH**/ ?>