<?php $__env->startSection('title','Coding Skill'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card mt-5 p-4">
        <div class="card-header bg-primary text-white"><h4>Blog Create Form</h4></div>
        <div class="card-body">
            <form action="<?php echo e(route('blog.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-dismissible fade show alert-danger" role="alert"  id="customxD">
                        <strong><?php echo e($error); ?></strong>
                        <button type="button" class="btn-close" data-mdb-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group mt-3">
                    <label for="title">Blog Title</label>
                    <input type="text" placeholder="Enter Title Name" name="title" class="form-control">
                </div>
                <div class="form-group mt-3">
                    <label for="description">Blog Description</label>
                    <textarea name="description" id="" cols="30" rows="5" class="form-control"></textarea>
                </div>

                <select name="category_id" id="" class="form-control mt-3">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <div class="form-group mt-3">
                    <label for="name">Image</label>
                    <input type="file"  name="image" class="form-control">
                </div>
                <button class="btn btn-primary mt-3"><i class="fas fa-paper-plane">Submit</i></button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PersonalBlog\resources\views/admin/Blog/create.blade.php ENDPATH**/ ?>